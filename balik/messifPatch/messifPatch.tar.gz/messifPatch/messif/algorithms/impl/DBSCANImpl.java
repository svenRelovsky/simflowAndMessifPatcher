/*
 *  This file is part of MESSIF library.
 *
 *  MESSIF library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  MESSIF library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with MESSIF library.  If not, see <http://www.gnu.org/licenses/>.
 */
package messif.algorithms.impl;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import java.util.TreeSet;
import messif.algorithms.Algorithm;
import messif.buckets.BucketDispatcher;
import messif.buckets.BucketStorageException;
import messif.buckets.impl.MemoryStorageBucket;
import messif.objects.LocalAbstractObject;
import messif.objects.impl.Tuple;
import messif.objects.util.RankedAbstractObject;
import messif.operations.AnswerType;
import messif.operations.query.RangeQueryOperation;

/**
 *
 * @author sven
 */
public class DBSCANImpl extends Algorithm{
    
    
    private List<Set<Integer>> resultIDSets;
    private List<Tuple<LocalAbstractObject, Integer>> allObjects;
    protected int minPts;
    private float eps;

    private VPTNode root;

    private final BucketDispatcher bucketDisp;

    private Set<Integer> noise;
    private Set<Integer> proccessedIDs;
    
    /** 
     * Creates DBSCAN = density based clustering algorithm 
     * 
     * @param eps minimal radius, in which one cluster core is
     * @param minPts minimal number of points with distance lesser than epsilon
     * @param data array of objects to run the algorithm on
     * @throws messif.buckets.BucketStorageException 
    */
    public DBSCANImpl(float eps, int minPts, ArrayList<? extends LocalAbstractObject> data)throws IllegalArgumentException, BucketStorageException{                
       super("DBSCAN - Density clustering algorithm");
        
        
        
        this.bucketDisp = new BucketDispatcher(
                Integer.MAX_VALUE,
                100,
                100,
                0,
                false,
                MemoryStorageBucket.class
        );
        this.root = new VPTNode(bucketDisp.createBucket());
        int i = 1;
        this.allObjects = new ArrayList<>();
        for (LocalAbstractObject ob1 : data) {
            Tuple<LocalAbstractObject, Integer> tup = new Tuple<>(ob1, i);
            //creating tuple with index by order(for control if it was processed)
            i++;
            root.insert(tup, bucketDisp);
            allObjects.add(tup);
    
    }
        
       
        resultIDSets= new ArrayList<>();
        this.noise = new TreeSet<>();
        this.proccessedIDs = new TreeSet<>();

        this.eps = eps;
        this.minPts = minPts;
    }

    
    /**
     * Run DBSCAN algorithm for given data, starting on first point.
     */
    public void run(){
        int clID = 1;

        resultIDSets.add(new TreeSet<>());
        
        for (int i = 0; i < allObjects.size(); i++) {
            if (noise.contains(allObjects.get(i)._2)) {
                    continue; // i+1
                }
            boolean bool;
            if (!proccessedIDs.contains(allObjects.get(i)._2)) {
                
                bool = expandCluster(allObjects.get(i), clID);
                if (bool) {
                    clID++;
                    
                    resultIDSets.add(new TreeSet<>());
                   
                }else{
                    //is noise
                    //noise.add(i+1);
                }
            }
        }
        
        
    }
    
    /**
     * Trying to expand cluster on the point
     * @param point point to be expanded
     * @param clID cluster ID where if possible will points be added
     * @return whether the expansion was successful or not
     */
    protected boolean expandCluster(Tuple  point, int clID){
      
        RangeQueryOperation op = new RangeQueryOperation(point, this.eps, AnswerType.CLEARED_OBJECTS);

       
        Set<Integer> wasQueued = new TreeSet<>();

        root.search(op);

        if (op.getAnswerCount() >= minPts) { 
            //will be cluster
            Iterator<RankedAbstractObject> it = op.getAnswer();
            Queue<Tuple> que = new LinkedList<>();
            while (it.hasNext()) {
                
                Tuple<LocalAbstractObject, Integer> t = (Tuple<LocalAbstractObject, Integer>) it.next().getObject();
                if(proccessedIDs.contains(t._2)) {
                    continue;
                }
                
                if(!noise.contains(t._2)){ 
                    que.add(t); 
                }else{
                    que.add(t);
                    addToClusterID(t, clID - 1);//noise so its surrounding is not > minPts
                }

            }

            Tuple<LocalAbstractObject, Integer> tupleOfQue = que.remove();

            
            addToClusterID(tupleOfQue, clID-1);
            
            while (!que.isEmpty()) {
                tupleOfQue = que.remove();
                if (wasQueued.contains(tupleOfQue._2)) {
                    continue;
                } else {
                    if(proccessedIDs.contains(tupleOfQue._2)){
                    
                    }else{
                        addToClusterID(tupleOfQue, clID - 1);
                    }
                    wasQueued.add(tupleOfQue._2);
                }
                op = new RangeQueryOperation(tupleOfQue, this.eps, AnswerType.CLEARED_OBJECTS);
                root.search(op);
                //adding to be processed
                if (op.getAnswerCount() >= minPts) {
                    it = op.getAnswer();
                    while (it.hasNext()) {
                        Tuple<LocalAbstractObject, Integer> tupleOfIterator
                                = (Tuple<LocalAbstractObject, Integer>) it.next().getObject();

                        if (noise.contains(tupleOfIterator._2) || !proccessedIDs.contains(tupleOfIterator._2)) {
                            if (!noise.contains(tupleOfIterator._2)) {
                                que.add(tupleOfIterator);

                            }
                                addToClusterID(tupleOfIterator, clID - 1);
                                                        
                        }
                    }
                }

            }

        } else {
            //not a cluster change point into noise
            noise.add((Integer) point._2);
            
            return false;
        }
        
        if(resultIDSets.get(clID-1).size()<minPts){
            /*Iterator<Integer> i =  resultIDSets.get(clID-1).iterator();
            while(i.hasNext()){
                noise.add(i.next());
            }*/
            resultIDSets.set(clID-1, new TreeSet<>());
        }
        return (resultIDSets.get(clID-1).size()>=10);
            
        }
    
    /**
     * Adding point into specific cluster
     *
     * @param point
     * @param clID
     */
    protected void addToClusterID(Tuple<LocalAbstractObject, Integer> point, int clID) {
        Set<Integer> a = resultIDSets.get(clID);
        a.add(point._2);
        
        proccessedIDs.add(point._2);
        if(noise.contains(point._2)){
            noise.remove(point._2);
        }
        
        resultIDSets.set(clID, a);
    }
    
    
    

 public void printClustersByID(String path) {
        Writer writer = null;
        try { // this should be one step higher?
            File dir = new File(path);
            dir.mkdir();
            dir = new File(path + "/clusters");
            dir.mkdir();
            File f = new File(path + "/clusters/" + "noise" + ".txt");
            writer = new BufferedWriter(
                    new OutputStreamWriter(
                            new FileOutputStream(f/*
                             path+"cluster"+clusterCount+".txt"
                             */),
                            "utf-8")
            );

            writer.write("#noise\n");
            //Iterator<Integer> it = noise.iterator();
           

            for (Integer it : this.noise) {
                
                Tuple<LocalAbstractObject, Integer> tup = allObjects.get(it-1);
                
                writer.write(tup.toString());
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (writer != null) {
                    writer.close();
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        for (int i = 0; i < resultIDSets.size() ; i++) { 
            if(resultIDSets.get(i).size() < minPts) break; // last empty cluster
            writer = null;

            try {

                File f = new File(path + "/clusters/" + "cluster_" + i + ".txt");
                writer = new BufferedWriter(
                        new OutputStreamWriter(
                                new FileOutputStream(f/*
                                 path+"cluster"+clusterCount+".txt"
                                 */),
                                "utf-8")
                );

                writer.write("#cluster " + i + "\n");
                Iterator<Integer> it  = resultIDSets.get(i).iterator();
              Integer k = it.next();
                while(it.hasNext() ) {

                    Tuple<LocalAbstractObject, Integer> tup = allObjects.get(k - 1);

                    writer.write(tup.toString());
                    k = it.next();
                }
                    Tuple<LocalAbstractObject, Integer> tup = allObjects.get(k - 1);

                    writer.write(tup.toString());
                    //writer.write(it.next().toString());
                

            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (writer != null) {
                        writer.close();
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

        }

    }

}
    


