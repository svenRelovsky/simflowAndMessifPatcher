/*
 *  This file is part of MESSIF library.
 *
 *  MESSIF library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  MESSIF library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with MESSIF library.  If not, see <http://www.gnu.org/licenses/>.
 */
package messif.algorithms.impl;

import java.util.Iterator;
import messif.buckets.BucketDispatcher;
import messif.buckets.BucketStorageException;
import messif.buckets.CapacityFullException;
import messif.buckets.LocalBucket;
import messif.objects.LocalAbstractObject;
import messif.objects.util.RankedAbstractObject;
import messif.objects.util.RankedSortedCollection;
import messif.operations.data.DeleteOperation;
import messif.operations.query.RangeQueryOperation;
import messif.pivotselection.AbstractPivotChooser;
import messif.pivotselection.RandomPivotChooser;

/**
 *
 * @author xrelovsk
 */
public class VPTNode {
    private LocalAbstractObject pivot;
    private float radius;
    private VPTNode leftNode;
    private VPTNode rightNode;
    private LocalBucket bucket;

    public VPTNode(LocalBucket bucket) {
        this.pivot = null;
        this.leftNode = null;
        this.rightNode = null;
        this.bucket = bucket;
    }

    public void insert(LocalAbstractObject obj, BucketDispatcher bucketDispatcher) throws BucketStorageException {
        if (bucket != null) {
            try {
                bucket.addObject(obj);
                return;
            } catch (CapacityFullException e) {
                split(bucketDispatcher);
            }
        }

        if (obj.getDistance(pivot) <= radius) {
            leftNode.insert(obj, bucketDispatcher);
        } else {
            rightNode.insert(obj, bucketDispatcher);
        }
    }

    private void split(BucketDispatcher bucketDispatcher) throws BucketStorageException {
        // Select pivot (by automatic pivot chooser)
       RandomPivotChooser pivotChooser = new RandomPivotChooser();
        pivotChooser.registerSampleProvider(bucket); //interface that buckets can provide
       pivot = pivotChooser.getNextPivot();

        // Compute distances to all objects
        RankedSortedCollection collection = new RankedSortedCollection(pivot, bucket);

        // Add first half to the left bucket
        leftNode = new VPTNode(bucketDispatcher.createBucket());
        Iterator<RankedAbstractObject> iterator = collection.iterator(0, collection.size() / 2);
        while (iterator.hasNext()) {
            RankedAbstractObject rankedObject = iterator.next();
            leftNode.bucket.addObject((LocalAbstractObject)rankedObject.getObject());
            radius = rankedObject.getDistance();
        }

        rightNode = new VPTNode(bucketDispatcher.createBucket());
        iterator = collection.iterator(collection.size() / 2, -1);
        while (iterator.hasNext())
            rightNode.bucket.addObject((LocalAbstractObject)iterator.next().getObject());

        // Clean up old bucket
        bucketDispatcher.removeBucket(bucket.getBucketID(), true);
        bucket = null;
    }

    public void rangeSearch(RangeQueryOperation operation) {
        if (bucket != null) {
            bucket.processQuery(operation);
        } else {
            float pivotDistance = operation.getQueryObject().getDistance(pivot);
            if (pivotDistance - operation.getRadius() <= radius)
                leftNode.rangeSearch(operation);
            if (pivotDistance + operation.getRadius() >= radius)
                rightNode.rangeSearch(operation);
        }
    }
    public void search(RangeQueryOperation operation){
        rangeSearch(operation);
    }
    public void delete(DeleteOperation op){
   //    bucket.delete(op.getDeletedObject(),op.getDeleteLimit());
    }
}
