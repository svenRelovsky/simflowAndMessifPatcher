/*
 *  This file is part of MESSIF library.
 *
 *  MESSIF library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  MESSIF library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with MESSIF library.  If not, see <http://www.gnu.org/licenses/>.
 */
package messif.objects.impl;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Objects;
import messif.objects.LocalAbstractObject;

/**
 * 
 * @author sven
 * @param <T>
 * @param <U> 
 */
public class Tuple<T extends LocalAbstractObject, U> extends LocalAbstractObject{

public T _1;
public U _2;
 
public Tuple(T arg1, U arg2) {
super();
this._1 = arg1;
this._2 = arg2;
}

    public Tuple(ObjectIntVectorL2 objectIntVectorL2) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
 
@Override
public String toString() {
return String.format("ID=%s %s\n", _2, _1);
}

public float getDistance(Tuple t2){
    return (this._1).getDistance(t2._1);
}
public U getArg2(){
    return this._2;
}
public void setArg2(U newVal){
    this._2 = newVal;
}

    @Override
    protected float getDistanceImpl(LocalAbstractObject obj, float distThreshold) {
        if(obj instanceof Tuple){      
            return (this._1).getDistance(((Tuple) obj)._1);
        } //To change body of generated methods, choose Tools | Templates.
        return (float) -1.0;
    }

    @Override
    public int getSize() {
        return _1.getSize();
    }

    @Override
    public boolean dataEquals(Object obj) {
        if(obj instanceof Tuple){         
            if(this._1.dataEquals(((Tuple) obj)._1) && (this._2 == ((Tuple)obj)._2)) {
              return true;
            }
        }
        return false;
    }

    @Override
    public int dataHashCode() {
        return _1.dataHashCode();
    }
    
    
    
    @Override
    protected void writeData(OutputStream stream) throws IOException {
       
        stream.write(this._1.toString().getBytes());
        stream.write(this._2.toString().getBytes());
        stream.write('\n');
    }

}

