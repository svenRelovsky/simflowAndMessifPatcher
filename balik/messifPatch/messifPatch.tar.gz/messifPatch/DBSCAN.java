/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import messif.algorithms.impl.DBSCANImpl;
import messif.objects.impl.ObjectIntVectorL2;

/**
 *
 * @author sven
 */
public class DBSCAN {

    public static void main(String[] args) throws Throwable {
        ArrayList<ObjectIntVectorL2> array = new ArrayList<>();

        String csvFile = null;
        if (args.length > 3) {
            csvFile = args[0];
        } else {
            System.err.println("Not enough arguments <path_to_csv> <epsilon> <minimal_number_of_points> <path_to_output>");
            //  note: clusters/ will be added to output directory
            System.exit(-1);
        }
        BufferedReader br = null;
        String line;
        String cvsSplitBy = " ";

        try {

            br = new BufferedReader(new FileReader(csvFile));
            br.readLine();

            while ((line = br.readLine()) != null) {

                // use space as separator
                String[] point = line.split(" ");
                Integer[] numPoint;

                if (point.length != 4) {
                    if (point.length == 2) {
                        array.add(new ObjectIntVectorL2(new int[]{
                            (int) Integer.parseInt(point[0]),
                            (int) Integer.parseInt(point[1])
                        }
                        )
                        );
                    }

                } else {
                    array.add(new ObjectIntVectorL2(new int[]{
                        (int) Integer.parseInt(point[0]),
                        (int) Integer.parseInt(point[1]),
                        (int) Integer.parseInt(point[2]),
                        (int) Integer.parseInt(point[3])
                    }
                    )
                    );
                }
            }

        } catch (FileNotFoundException e) {
            System.err.println("File unreachable");
        } catch (IOException e) {
            System.err.println("File unreachable");
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    System.err.println("File unreachable");
                }
            }
        }

        System.out.println("Input read");

        float eps = 0;
        int minPts = 0;
        if (args.length > 3) {
            eps = Integer.parseInt(args[1]);
        }
        if (args.length > 3) {
            minPts = Integer.parseInt(args[2]);
        }
        System.out.println("minpts: " + minPts);
        long startTime;
        long endTime;
        startTime = System.currentTimeMillis();
        //DBSCANImpl db = new DBSCANImpl(eps, minPts, array);
        DBSCANImpl db = new DBSCANImpl(eps, minPts, array);
        endTime = System.currentTimeMillis();
        System.out.println("Time of creating tree structure " + (endTime - startTime) + " ms");
        startTime = System.currentTimeMillis();
        db.run();
        endTime = System.currentTimeMillis();
        db.printClustersByID(args[3]);
        System.out.println("Time of algorithm computation " + (endTime - startTime) + " ms");

    }

}
